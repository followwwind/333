package BombExplode;

import org.w3c.dom.Node;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class Queue<T> implements Iterable<T> {
    private Node head;  //首结点
    private Node last;  //尾结点
    private int N;


    public class Node{
        public T data;
        public Node next;
        public Node(T data,Node next){
            this.data=data;
            this.next=next;
        }
    }

    public Queue(){
        this.head=new Node(null,null);
        this.last=null;
        this.N=0;
    }

    public boolean isEmpty(){
        return N==0;
    }

    public int size(){
        return N;
    }

    //向队列中插入元素
    public void enqueue(T t){
        //当前尾结点为null
        if(last==null){
            last=new Node(t, null);
            head.next=last;
        }else{
            Node oldLast=last;
            last=new Node(t,null);
            oldLast.next=last;
        }

        N++;
    }

    //从队列中拿出一个元素(先进先出)
    public T dequeue(){
        if(isEmpty()){
            return null;
        }
        Node oldFirst=head.next;
        head.next=oldFirst.next;
        N--;
        if(isEmpty()){
            last=null;
        }
        return oldFirst.data;
    }

    @Override
    public Iterator iterator() {
        return new QIterator();
    }

    private class QIterator implements Iterator{

        private Node n;

        public QIterator(){
            this.n=head;
        }

        @Override
        public boolean hasNext() {
            return n.next!=null;
        }

        @Override
        public Object next() {
            n=n.next;
            return n.data;
        }
    }
}
