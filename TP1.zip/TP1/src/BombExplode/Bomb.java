package BombExplode;

import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Bomb  {
    public static void main(String[] args ) {
        try {
            File myObj = new File(args[0]);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
       Queue queue=new Queue<>();
       Queue queue1=new Queue();
        int[][] a=new int[2][3];
        a[0][0]=1;
        a[0][1]=2;
        a[0][2]=0;

        a[1][0]=0;
        a[1][1]=0;
        a[1][2]=1;

          //遍历炸弹列表，找出炸弹位置并存入到队列当中。
         for (int i=0;i<a.length;i++){
            for (int j=0;j<a[i].length;j++){
                //咋到炸弹
                if (a[i][j]==2){
                    //存入炸弹
                    queue.enqueue(a[i][j]);
                }
            }
        }

        }
    }
}
