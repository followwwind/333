package com.liaoxiang.multimeter.utils;

import com.liaoxiang.multimeter.pojo.Answer;
import com.liaoxiang.multimeter.pojo.Parameter;
import com.liaoxiang.multimeter.pojo.parameter.ParameterData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 16:14
 */
public class LocalCatch {

    public static volatile boolean start = false;
    // 管理员账户 用户名 - 密码
    public static Map<String, String> adminMap = new HashMap<>(1);
    // 存放万用表参数 用户id - 参数
    public static Map<Integer, ParameterData> parameterMap = new HashMap<>();
    //
    public static Map<String, List<Integer>> parameterArrayMap = new HashMap<>();
    // 保存答案
    public static Map<String, List<Answer>> answerMap = new HashMap<>();

    static{
        adminMap.put("admin", "admin");
    }

}
