package com.liaoxiang.multimeter.utils;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.liaoxiang.multimeter.pojo.PdfData;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class PdfUtils {

    public static void createPDF(PdfData pdfData) throws IOException {
        Document document = new Document(PageSize.A4, 0,0,36,36);
        try {
            PdfWriter.getInstance(document, new FileOutputStream(pdfData.getFilename()));
            document.addTitle(pdfData.getName()+"成绩单");
            document.open();
            document.add(createTable(pdfData));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }

    public static PdfPTable createTable(PdfData pdfData) throws IOException, DocumentException {

        Font font = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        font.setSize(14);

        BaseFont bfComic = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED);
        Font font1 = new Font(bfComic, 14);


        PdfPTable table = new PdfPTable(12);//生成一个12列的表格
        PdfPCell cell;



        Font f1 = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f1.setSize(18);
        cell = new PdfPCell(new Phrase("计量检定人员操作考核记录", f1));
        cell.setColspan(12);//合并列
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.disableBorderSide(15);//去掉边框
        table.addCell(cell);

        //---------------------------------------个人信息-----------------------------------
        cell = new PdfPCell(new Phrase("工作单位：", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        table.addCell(cell);

//        工作单位
        cell = new PdfPCell(new Phrase(pdfData.getWorkUnit(), font));
        cell.setColspan(6);
        cell.setFixedHeight(30);
        cell.setPaddingLeft(10);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("姓名：", font));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        cell.setColspan(2);
        cell.setFixedHeight(30);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getName(), font));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        cell.setColspan(2);
        cell.setFixedHeight(30);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核项目：", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getProject(), font));
        cell.setColspan(6);
        cell.setFixedHeight(30);
        cell.setPaddingLeft(10);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("总分：", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
//        cell.setPaddingLeft(10);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.disableBorderSide(15);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getTotalScore(), font));
        cell.disableBorderSide(15);
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setPaddingLeft(10);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(cell);

        //---------------------------------------被检测量器具-----------------------------------
        Font f2 = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f2.setSize(14);
        cell = new PdfPCell(new Phrase("被检\n测量\n器具", f2));
        cell.setColspan(1);//占用一列
        cell.setRowspan(3);//占用三行
        cell.setFixedHeight(90);//设置高度
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setLeading(26f,0f);
        cell.setPaddingBottom(10.0f);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("名称", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("准确度等级", font));
        cell.setColspan(4);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(30);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("型号规格", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("出厂编号", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setRowspan(2);
        cell.setFixedHeight(60);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(4);
        cell.setRowspan(2);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(2);
        cell.setRowspan(2);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setRowspan(2);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);


        //----------------------------------所使用的计量标准---------------------------------

        Font f3 = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f3.setSize(14);
        cell = new PdfPCell(new Phrase("所使\n用的\n计量\n标准", f3));
        cell.setColspan(1);//占用一列
        cell.setRowspan(4);//占用三行
        cell.setFixedHeight(120);//设置高度
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setLeading(26f,0f);
        cell.setPaddingBottom(10.0f);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("名称", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("准确度等级", font));
        cell.setColspan(4);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(30);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("型号规格", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("出厂编号", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setRowspan(3);
        cell.setFixedHeight(60);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(4);
        cell.setRowspan(3);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(2);
        cell.setRowspan(3);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setRowspan(3);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setFixedHeight(60);
        table.addCell(cell);


        //---------------------------------环境条件-----------------------------------
        cell = new PdfPCell(new Phrase("环境\n条件", font));
        cell.setColspan(1);
        cell.setRowspan(2);
        cell.setFixedHeight(60);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setLeading(21f,0f);
        cell.setPaddingBottom(4.0f);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("温度", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("相对湿度", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("其他", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(9);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核评分记录", font));
        cell.setColspan(12);//合并列
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核内容", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核要求", font));
        cell.setColspan(4);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("评分", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("记事", font));
        cell.setColspan(4);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        // -----------------------------第一个表格-------------------
        Font f_table1_1 = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f_table1_1.setSize(16);
        cell = new PdfPCell(new Phrase("一、\n" +
                "按  检\n" +
                "定  规\n" +
                "程  检\n" +
                "定  操\n" +
                "作  程\n" +
                "序  正\n" +
                "确  性\n" +
                "(20分)", f_table1_1));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(350);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);


        Font f_table1_2 = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f_table1_2.setSize(13);
        cell = new PdfPCell(new Phrase( "1. 能正确完成检定操作前的设备外观检查、预热和加电功能检查；\n" +
                "2. 能正确选择检定项目；\n" +
                "3. 能正确完成测量点的选择；\n" +
                "4. 检定完成后，能正确完成仪器整理工作；\n" +
                "5. 出具检定证书。", f_table1_2));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(350);
        cell.setLeading(30f,0f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getScore1(), font));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(350);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(350);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);


        // -----------------------------第二页--------------------------
        cell = new PdfPCell(new Phrase("考核内容", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核要求", font));
        cell.setColspan(4);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("评分", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("记事", font));
        cell.setColspan(4);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        //---------------------------------------第二个表格-----------------------------
        cell = new PdfPCell(new Phrase("二、\n" +
                "按 检\n" +
                "定 规\n" +
                "程 检\n" +
                "定 操\n" +
                "作 方\n" +
                "法 正\n" +
                "确 性\n" +
                "及 熟\n" +
                "练 程\n" +
                "度(40分)\n", f_table1_1));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(340);
        cell.setLeading(25f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(20);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("1. 能正确选择标准仪器型号；\n" +
                "2. 能正确完成各测量点的检定操作，无误操作；\n" +
                "3. 在接入被测件进行检定时，操作规范。", f_table1_2));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(340);
        cell.setLeading(30f,0f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getScore2(), font));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(340);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(340);
        cell.setLeading(30f,0f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);


        //----------------------------第三个表-------------------------
        cell = new PdfPCell(new Phrase("三、\n" +
                "数据\n" +
                "处理\n" +
                "与证\n" +
                "书填\n" +
                "写的\n" +
                "正确\n" +
                "性(40分)\n", f_table1_1));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(310);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(30);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("1. 记录检定数据；按仪器显示分辨率读数、记录按有效位数的要求、发现错误用划改并签章；\n" +
                "2. 出具检定证书。按检定规程及仪器指标的要求进行是否合格的判定，并给出结论；\n" +
                "3. 出具检定证书一份。", font));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(310);
        cell.setLeading(30f,0f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(20);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(pdfData.getScore3(), font));
        cell.setColspan(2);
        cell.setRowspan(10);
        cell.setFixedHeight(310);
        cell.setLeading(30f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(4);
        cell.setRowspan(10);
        cell.setFixedHeight(310);
        cell.setLeading(30f,0f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(40);
        table.addCell(cell);


        Font f_zhu = new Font(BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
                BaseFont.NOT_EMBEDDED));
        f_zhu.setSize(16);
        cell = new PdfPCell(new Phrase("主\n考\n人", f_zhu));
        cell.setColspan(1);
        cell.setRowspan(3);
        cell.setFixedHeight(90);
        cell.setLeading(25f,0f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        cell.setPaddingBottom(12);
        table.addCell(cell);



        cell = new PdfPCell(new Phrase("姓名", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("职称", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("聘书号", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("考核时间", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        //        主考人
        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(2);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", font));
        cell.setColspan(3);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);//设置水平居中
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);//设置垂直居中
        table.addCell(cell);
        return table;
    }
}