package com.liaoxiang.multimeter.pojo.parameter;

import lombok.Data;

import java.util.ArrayList;

/**
 * @auther Mr.Liao
 * @date 2021/6/14 18:57
 *
 * 每一个项目参数
 */
@Data
public class Parameter {
    // 项目标识 0-4
    private int type;
    private ArrayList<Item> items;
}
