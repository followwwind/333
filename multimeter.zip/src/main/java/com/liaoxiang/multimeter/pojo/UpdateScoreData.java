package com.liaoxiang.multimeter.pojo;

import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/6/4 19:16
 */
@Data
public class UpdateScoreData {
    private String name;
    private double score;
    private String title;
    private Integer parent;
}
