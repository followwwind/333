package com.liaoxiang.multimeter.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * @auther Mr.Liao
 * @date 2021/6/1 16:56
 */
@Data
@NoArgsConstructor
public class Examination {
    private String title;
    private ArrayList<String> options;
}
