package com.liaoxiang.multimeter.pojo.validity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @auther Mr.Liao
 * @date 2021/6/15 22:49
 */
@Data
@TableName("tb_validity")
@NoArgsConstructor
public class Validity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String project;//项目
    private String vRange;//量程
    private String point;//区间
    private String section;//范围
    @TableField("stu_id")
    private Integer stuId;

    public Validity(String project, String vRange, String point, String section, Integer stuId) {
        this.project = project;
        this.vRange = vRange;
        this.point = point;
        this.section = section;
        this.stuId = stuId;
    }
}
