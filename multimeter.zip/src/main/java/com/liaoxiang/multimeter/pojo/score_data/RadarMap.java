package com.liaoxiang.multimeter.pojo.score_data;

import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/6/5 15:25
 */
@Data
public class RadarMap {
    private String name;
    private String[] value;
}
