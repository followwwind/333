package com.liaoxiang.multimeter.pojo.score_data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/6/2 13:12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoreDataTwo {
    private Integer id;
    private String project;
    private String score;
    private String total;
    private Integer parent;
    private List<ScoreDataTwo> children;
    private Integer tableId;
}
