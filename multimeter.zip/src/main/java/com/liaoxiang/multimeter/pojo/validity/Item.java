package com.liaoxiang.multimeter.pojo.validity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Item {
    private String vRange;//量程
    private String point;//区间
    private String section;//范围
}
