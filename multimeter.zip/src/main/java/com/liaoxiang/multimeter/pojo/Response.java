package com.liaoxiang.multimeter.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/5/28 8:54  变量类型 变量名  int a = 0
 */
@Data
@AllArgsConstructor
public class Response {
    private int type;
    private boolean flag;
    private String msg;
    private Object data;

    public Response(boolean flag, String msg, Object data) {
        this.flag = flag;
        this.msg = msg;
        this.data = data;
    }
}
