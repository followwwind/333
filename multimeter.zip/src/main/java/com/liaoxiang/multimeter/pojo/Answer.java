package com.liaoxiang.multimeter.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @auther Mr.Liao
 * @date 2021/6/1 16:45
 */
@Data
@NoArgsConstructor
@TableName("tb_score")

public class Answer {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String name;
    private Integer parent;
    private String title;
    private String score;
    private String total;
    private Integer orderNumber;

    public Answer(String name, Integer parent, String title, String score, String total) {
        this.name = name;
        this.parent = parent;
        this.title = title;
        this.score = score;
        this.total = total;
    }

    public Answer(String name, Integer parent, String title, String score, String total, Integer orderNumber) {
        this.name = name;
        this.parent = parent;
        this.title = title;
        this.score = score;
        this.total = total;
        this.orderNumber = orderNumber;
    }
}
