package com.liaoxiang.multimeter.pojo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:38
 */
@Data
@TableName("tb_student")
public class Student {
    @TableId(type = IdType.AUTO)
    private Integer id;
    @ExcelProperty("姓名")
    private String name;
    private String password;
    @ExcelProperty("性别")
    private String gender;//性别
    @ExcelProperty("身份证号")
    private String idCard;//身份证
    @ExcelProperty("手机")
    private String phone;//电话
    @ExcelProperty("工作单位")
    private String workUnit;//工作单位
    @ExcelProperty("学历")
    private String education;//学历
    @ExcelProperty("毕业院校")
    private String school;//学校
    @ExcelProperty("专业")
    private String major;//专业
    @ExcelProperty("参加工作时间")
    private Date hireDate;//入职时间
    @ExcelProperty("检定员证号")
    private String examinerNumber;
    @ExcelProperty("首次取证时间")
    private Date firstTime;
    @ExcelProperty("申请考试批次")
    private String examBatch;//考试批次
    @ExcelProperty("申请考试科目")
    private String project;//考核项目
    private String ip;//终端ip
    private Boolean state;//是否在线
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ExcelProperty("考试时间")
    private Date examStartTime;//考试开始时间
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date examEndTime;// 考试结束时间
    private Boolean scored;//是否评分
    private String examState;//考试状态
    private Boolean started;//开始考试标识
    private Boolean parameterState;//是否设置了参数
    private String totalScore;//总分
}
