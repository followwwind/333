package com.liaoxiang.multimeter.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/5/28 9:54
 */
@Data
@AllArgsConstructor
public class ExamInfo {
    private Integer type;
    private List<Integer> items;
}
