package com.liaoxiang.multimeter.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/5/28 9:52
 */
@Data
@AllArgsConstructor
public class StuLoginData {
    private Student student;
}
