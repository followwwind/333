package com.liaoxiang.multimeter.pojo.parameter;

import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/6/14 18:58
 */
@Data
public class Item {
    private String range;//量程
    private String point;//测量点
    private String error;//误差
    private String scope;//波动值
}
