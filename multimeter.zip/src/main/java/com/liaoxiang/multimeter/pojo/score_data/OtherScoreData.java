package com.liaoxiang.multimeter.pojo.score_data;

import lombok.Data;

/**
 * @auther Mr.Liao
 * @date 2021/6/5 14:53
 */
@Data
public class OtherScoreData {
    private String name;
    private int[] scores;
}
