package com.liaoxiang.multimeter.pojo.score_data;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/6/2 13:10
 */
@Data
public class ScoreDataOne {
    private Integer id;
    private String project;
    private String score;
    private String examState;
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date total;
    private List<String> manualScore;
    private String totalScore;//总分
    private List<ScoreDataTwo> children;

}
