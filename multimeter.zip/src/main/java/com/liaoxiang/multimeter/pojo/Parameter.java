package com.liaoxiang.multimeter.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * @auther Mr.Liao
 * @date 2021/5/28 16:53
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Parameter {
    private String id;
    private String deviation;
    private String fluctuate;
    private ArrayList<Integer> items;
}
