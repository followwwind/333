package com.liaoxiang.multimeter.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @auther Mr.Liao
 * @date 2021/6/19 14:55
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PdfData {
    private String workUnit;
    private String name;
    private String project;
    private String totalScore;
    private String score1;
    private String score2;
    private String score3;
    private String filename;
}
