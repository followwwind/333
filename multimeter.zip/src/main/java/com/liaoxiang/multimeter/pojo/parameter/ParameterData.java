package com.liaoxiang.multimeter.pojo.parameter;

import lombok.Data;

import java.util.ArrayList;

/**
 * @auther Mr.Liao
 * @date 2021/6/14 19:41
 */
@Data
public class ParameterData {
    private int id;
    private ArrayList<Parameter> parameters;
}
