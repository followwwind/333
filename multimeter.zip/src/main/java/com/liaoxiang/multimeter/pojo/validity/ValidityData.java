package com.liaoxiang.multimeter.pojo.validity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ValidityData {
    private String project;
    private List<Item> items;
}
