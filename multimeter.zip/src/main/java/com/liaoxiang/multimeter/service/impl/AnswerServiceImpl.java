package com.liaoxiang.multimeter.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.liaoxiang.multimeter.config.MultimeterProperties;
import com.liaoxiang.multimeter.mapper.AnswerMapper;
import com.liaoxiang.multimeter.pojo.*;
import com.liaoxiang.multimeter.pojo.score_data.OtherScoreData;
import com.liaoxiang.multimeter.pojo.score_data.RadarMap;
import com.liaoxiang.multimeter.service.IAnswerService;
import com.liaoxiang.multimeter.utils.PdfUtils;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:35
 */
@Service
public class AnswerServiceImpl extends ServiceImpl<AnswerMapper, Answer> implements IAnswerService {

    @Autowired
    StudentServiceImpl studentService;

    @Autowired
    MultimeterProperties multimeterProperties;

    public void setDefaultScore() {
        List<Student> students = studentService.list();
        ArrayList<String> titleList = new ArrayList<>();
        titleList.add("环境搭建");
        titleList.add("外观检查");
        titleList.add("预热时间");
        titleList.add("加电检查");
        titleList.add("检定项目选择");
        for (int i = 0; i < 5; i++) {
            titleList.add("连线");
            titleList.add("选点");
            titleList.add("操作");
        }
        ArrayList<String> totalList = new ArrayList<>();
        totalList.add("5");
        totalList.add("0.5");
        totalList.add("1");
        totalList.add("0.5");
        totalList.add("1");
        for (int i = 0; i < 5; i++) {
            totalList.add("1");
            totalList.add("1");
            totalList.add("6");
        }
        ArrayList<Integer> parentList = new ArrayList<>();
        parentList.add(0);
        parentList.add(2);
        parentList.add(2);
        parentList.add(2);
        parentList.add(0);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                parentList.add(5);
            }
            for (int j = 0; j < 3; j++) {
                parentList.add(6);
            }
            for (int j = 0; j < 3; j++) {
                parentList.add(7);
            }
            for (int j = 0; j < 3; j++) {
                parentList.add(8);
            }
            for (int j = 0; j < 3; j++) {
                parentList.add(9);
            }
        }

        for (Student student : students) {
            for (int i = 0; i < 20; i++) {
                Answer answer = new Answer(student.getName(), parentList.get(i), titleList.get(i), "0", totalList.get(i));
                studentService.saveAnswerIfNull(answer);
            }
        }
    }

    public List<Answer> getByNameAndParent(String name, Integer parent) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name).eq("parent", parent);
        return list(wrapper);
    }


    public List<Answer> getByNameAndTitle(String name, String title) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name).eq("title", title);
        return list(wrapper);
    }


    /**
     * 修改每一小项目的分数
     *
     * @param tableId
     * @param score
     */
    public void updateScore(Integer tableId, String score) {
        UpdateWrapper<Answer> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", tableId).set("score", score);
        update(wrapper);
    }

    /**
     * "熟练程度"
     * "实验后仪器整理"
     * "原始记录"
     * "报告正确性"
     *
     * @param scoreData
     */
    public void saveScore(OtherScoreData scoreData) {
        String name = scoreData.getName();
        Answer answer = new Answer();
        int[] scores = scoreData.getScores();
        List<String> titles = Arrays.asList("熟练程度", "原始记录", "报告正确性","实验后仪器整理");
        for (int i = 0; i < scores.length; i++) {
            Answer ans = new Answer();
            ans.setName(name);
            ans.setScore(String.valueOf(scores[i]));
            ans.setTitle(titles.get(i));
            ans.setParent(-1);
            if ("熟练程度".equals(titles.get(i))) {
                ans.setTotal(String.valueOf(10));
                ans.setOrderNumber(5);
            }
            if ("原始记录".equals(titles.get(i))) {
                ans.setTotal(String.valueOf(20));
                ans.setOrderNumber(6);
            }
            if ("报告正确性".equals(titles.get(i))) {
                ans.setTotal(String.valueOf(20));
                ans.setOrderNumber(7);
            }
            if ("实验后仪器整理".equals(titles.get(i))) {
                ans.setTotal(String.valueOf(2));
                ans.setOrderNumber(8);
            }


            Answer oldAnswer = getAnswerByNameTitle(name, ans.getTitle());
            if (oldAnswer == null) {
                save(ans);
            } else {
                oldAnswer.setScore(String.valueOf(scores[i]));
                updateById(oldAnswer);
            }
        }
        //修改评分标识
        studentService.updateScored(scoreData.getName());
        updateTranscript(scoreData.getName());

    }

    public void updateTranscript(String name) {
        //查询成绩
        List<Answer> answers = studentService.getScoreByName(name);
        double score1 = 0;
        double score2 = 0;
        double score3 = 0;
        for (Answer ans : answers) {
            if (ans.getTitle().equals("环境搭建")) {
                score1 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("准备工作")) {
                score1 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("检定项目选择")) {
                score1 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("检定过程")) {
                score2 = Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("熟练程度")) {
                score1 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("实验后仪器整理")) {
                score1 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("原始记录")) {
                score3 += Double.valueOf(ans.getScore());
            }
            if (ans.getTitle().equals("报告正确性")) {
                score3 += Double.valueOf(ans.getScore());
            }

        }

        Student stu = studentService.getByName(name);
        String scorePath = multimeterProperties.getScorePath();
        PdfData pdfData = new PdfData();
        pdfData.setName(stu.getName());
        pdfData.setWorkUnit(stu.getWorkUnit());
        pdfData.setProject(stu.getProject());
        pdfData.setScore1(String.valueOf(score1));
        pdfData.setScore2(String.valueOf(score2));
        pdfData.setScore3(String.valueOf(score3));
        pdfData.setTotalScore(String.valueOf(score1  + score2 + score3));
        pdfData.setFilename(scorePath+stu.getIdCard()+"transcript.pdf");
        //生成成绩单
        try {
            PdfUtils.createPDF(pdfData);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //更新学生总分
        stu.setTotalScore(pdfData.getTotalScore());
        studentService.updateById(stu);
    }

    public RadarMap getRadarMap(String name) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name).eq("parent", -1).orderByAsc("order_number");
        List<Answer> list = list(wrapper);
        RadarMap radarMap = new RadarMap();
        radarMap.setName("成绩");
        String[] data = new String[list.size()];
        for (int i = 0; i < data.length; i++) {
            data[i] = list.get(i).getScore();
        }
        radarMap.setValue(data);
        return radarMap;

    }

    public Answer getAnswerByNameTitle(String name, String title) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name).eq("title", title);
        return getOne(wrapper);
    }

    public void deleteOldData(String name) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name);
        remove(wrapper);
    }


}
