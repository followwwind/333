package com.liaoxiang.multimeter.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.Query;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.liaoxiang.multimeter.mapper.StudentMapper;
import com.liaoxiang.multimeter.pojo.Answer;
import com.liaoxiang.multimeter.pojo.ExamInfo;
import com.liaoxiang.multimeter.pojo.Student;
import com.liaoxiang.multimeter.pojo.validity.Validity;
import com.liaoxiang.multimeter.pojo.parameter.Item;
import com.liaoxiang.multimeter.pojo.parameter.Parameter;
import com.liaoxiang.multimeter.pojo.parameter.ParameterData;
import com.liaoxiang.multimeter.pojo.score_data.ScoreDataOne;
import com.liaoxiang.multimeter.pojo.score_data.ScoreDataTwo;
import com.liaoxiang.multimeter.service.IStudentService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.lang.management.ManagementFactory;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.*;

import static com.liaoxiang.multimeter.utils.LocalCatch.parameterMap;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:35
 */
@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student> implements IStudentService {


    @Autowired
    AnswerServiceImpl answerService;

    @Autowired
    ValidityServiceImpl validityService;

    @Autowired
    LogDataServiceImpl logDataService;

    /**
     * 更新开始考试标识
     *
     * @param stuId
     */
    public void updateStarted(Integer stuId, Boolean flag) {
        Student student = new Student();
        student.setId(stuId);
        student.setStarted(flag);
        student.setExamState("正在考试中");
        student.setExamEndTime(null);
        student.setTotalScore(" ");
        student.setScored(false);//是否完成评分
        updateById(student);
        Student stu = getById(stuId);
        // 检查是否有旧的数据
        logDataService.deleteOldData(stu.getName());
        answerService.deleteOldData(stu.getName());
        validityService.deleteOldData(student.getId());
    }


    /**
     * 获取某个人的大类分数
     *
     * @param name
     * @return
     */
    public List<Answer> getScoreByName(String name) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name).eq("parent", -1);
        return answerService.list(wrapper);
    }


    /**
     * 修改已经评分标识
     *
     * @param name
     */
    public void updateScored(String name) {
        UpdateWrapper<Student> wrapper = new UpdateWrapper<>();
        wrapper.eq("name", name).set("scored", true);
        update(wrapper);
    }

    /**
     * 根据身份证查询学生信息
     *
     * @param idCard
     * @return
     */
    public Student getStuByIdCard(String idCard) {
        QueryWrapper<Student> wrapper = new QueryWrapper<>();
        wrapper.eq("id_card", idCard);
        return getOne(wrapper);
    }


    public Student getByName(String name) {
        QueryWrapper<Student> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name);
        return getOne(wrapper);
    }


    /**
     * 考生登录
     *
     * @param name
     * @param password
     * @return
     */
    public Student login(String name, String password) {
        QueryWrapper<Student> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", name).eq("password", password);
        return getOne(queryWrapper);
    }

    /**
     * 查询考试信息
     *
     * @param id
     * @return
     */
    public ExamInfo getExamInfo(Integer id) {
        ArrayList<Integer> items = new ArrayList<>();
        items.add(0);
        items.add(1);
        items.add(2);
        items.add(3);
        items.add(4);
        return new ExamInfo(1, items);
    }


    /**
     * 设置参数
     *
     * @param parameterData
     */
    public void setParameter(ParameterData parameterData) {
        ArrayList<Parameter> list = parameterData.getParameters();
        if (CollectionUtils.isEmpty(list)) {
            parameterMap.remove(parameterData.getId());
        } else {
            parameterMap.put(parameterData.getId(), parameterData);
            // 更新设置参数的标识
            int stuId = parameterData.getId();
            Student student = getById(stuId);
            student.setParameterState(true);
            updateById(student);
        }
    }


    /**
     * 设置正确性数据
     *
     * @param parameterData
     */
    public void setValidity(ParameterData parameterData) {
        //设置正确性数据
        ArrayList<Parameter> parameters = parameterData.getParameters();
        for (Parameter parameter : parameters) {
            int type = parameter.getType();
            ArrayList<Item> items = parameter.getItems();
            // 直流电压
            if (type == 0) {
                for (Item item : items) {
                    String point = item.getPoint();
                    String pointNumStr;
                    // 单位是mV
                    if (point.contains("m")) {
                        pointNumStr = point.substring(0, point.indexOf("m"));
                    } else { // 单位是V
                        pointNumStr = point.substring(0, point.indexOf("V"));
                    }
                    // 测量点的值 10m
                    BigDecimal bPoint = new BigDecimal(pointNumStr);

                    BigDecimal b1 = new BigDecimal("100");//100
                    BigDecimal b2 = new BigDecimal(item.getError());//10
                    BigDecimal b3 = b1.add(b2);//110
                    // 误差
                    BigDecimal bError = b3.divide(b1);//1.1
                    // 波动值 0.01
                    BigDecimal bScope = new BigDecimal(item.getScope());
                    //上限 10*1.1+0.01
                    BigDecimal bUpper = bPoint.multiply(bError).add(bScope);
                    //下限
                    BigDecimal bFloor = bPoint.multiply(bError).subtract(bScope);
                    String section = "[" + bFloor.toString() + ", " + bUpper.toString() + "]";
                    Validity validity = new Validity("直流电压", item.getRange(), item.getPoint(), section, parameterData.getId());
                    Validity byCondition = validityService.getByCondition(validity.getProject(), validity.getPoint(), validity.getStuId());
                    if (byCondition == null) {
                        validityService.save(validity);
                    } else {
                        byCondition.setSection(validity.getSection());
                        validityService.updateById(byCondition);
                    }

                }
            }

            // 直流电流
            if (type == 1) {
                for (Item item : items) {
                    String point = item.getPoint();
                    String pointNumStr;
                    // 单位是mV
                    if (point.contains("m")) {
                        pointNumStr = point.substring(0, point.indexOf("m"));
                    } else { // 单位是V
                        pointNumStr = point.substring(0, point.indexOf("A"));
                    }
                    // 测量点的值 10m
                    BigDecimal bPoint = new BigDecimal(pointNumStr);

                    BigDecimal b1 = new BigDecimal("100");//100
                    BigDecimal b2 = new BigDecimal(item.getError());//10
                    BigDecimal b3 = b1.add(b2);//110
                    // 误差
                    BigDecimal bError = b3.divide(b1);//1.1
                    // 波动值 0.01
                    BigDecimal bScope = new BigDecimal(item.getScope());
                    //上限 10*1.1+0.01
                    BigDecimal bUpper = bPoint.multiply(bError).add(bScope);
                    //下限
                    BigDecimal bFloor = bPoint.multiply(bError).subtract(bScope);
                    String section = "[" + bFloor.toString() + ", " + bUpper.toString() + "]";
                    Validity validity = new Validity("直流电流", item.getRange(), item.getPoint(), section, parameterData.getId());
                    Validity byCondition = validityService.getByCondition(validity.getProject(), validity.getPoint(), validity.getStuId());
                    if (byCondition == null) {
                        validityService.save(validity);
                    } else {
                        byCondition.setSection(validity.getSection());
                        validityService.updateById(byCondition);
                    }
                }
            }
            // 交流电压
            if (type == 2) {
                for (Item item : items) {
                    String point = item.getPoint();
                    String pointNumStr;
                    // 单位是mV
                    if (point.contains("m")) {
                        pointNumStr = point.substring(0, point.indexOf("m"));
                    } else { // 单位是V
                        pointNumStr = point.substring(0, point.indexOf("V"));
                    }
                    // 测量点的值 10m
                    BigDecimal bPoint = new BigDecimal(pointNumStr);

                    BigDecimal b1 = new BigDecimal("100");//100
                    BigDecimal b2 = new BigDecimal(item.getError());//10
                    BigDecimal b3 = b1.add(b2);//110
                    // 误差
                    BigDecimal bError = b3.divide(b1);//1.1
                    // 波动值 0.01
                    BigDecimal bScope = new BigDecimal(item.getScope());
                    //上限 10*1.1+0.01
                    BigDecimal bUpper = bPoint.multiply(bError).add(bScope);
                    //下限
                    BigDecimal bFloor = bPoint.multiply(bError).subtract(bScope);
                    String section = "[" + bFloor.toString() + ", " + bUpper.toString() + "]";
                    Validity validity = new Validity("交流电压", item.getRange(), item.getPoint(), section, parameterData.getId());
                    Validity byCondition = validityService.getByCondition(validity.getProject(), validity.getPoint(), validity.getStuId());
                    if (byCondition == null) {
                        validityService.save(validity);
                    } else {
                        byCondition.setSection(validity.getSection());
                        validityService.updateById(byCondition);
                    }
                }
            }
            // 交流电流
            if (type == 3) {
                for (Item item : items) {
                    String point = item.getPoint();
                    String pointNumStr = "1";
                    BigDecimal bPoint = new BigDecimal(pointNumStr);
                    BigDecimal b1 = new BigDecimal("100");//100
                    BigDecimal b2 = new BigDecimal(item.getError());//10
                    BigDecimal b3 = b1.add(b2);//110
                    // 误差
                    BigDecimal bError = b3.divide(b1);//1.1
                    // 波动值 0.01
                    BigDecimal bScope = new BigDecimal(item.getScope());
                    //上限 10*1.1+0.01
                    BigDecimal bUpper = bPoint.multiply(bError).add(bScope);
                    //下限
                    BigDecimal bFloor = bPoint.multiply(bError).subtract(bScope);
                    String section = "[" + bFloor.toString() + ", " + bUpper.toString() + "]";
                    Validity validity = new Validity("交流电流", item.getRange(), item.getPoint(), section, parameterData.getId());
                    Validity byCondition = validityService.getByCondition(validity.getProject(), validity.getPoint(), validity.getStuId());
                    if (byCondition == null) {
                        validityService.save(validity);
                    } else {
                        byCondition.setSection(validity.getSection());
                        validityService.updateById(byCondition);
                    }
                }
            }

            // 直流电阻
            if (type == 4) {
                for (Item item : items) {
                    String point = item.getPoint();
                    String pointNumStr;
                    // 单位是kΩ
                    if (point.contains("k")) {
                        pointNumStr = point.substring(0, point.indexOf("k"));
                    } else if (point.contains("M")) {//单位是MΩ
                        pointNumStr = point.substring(0, point.indexOf("M"));
                    } else { // 单位是Ω
                        pointNumStr = point.substring(0, point.indexOf("O"));
                    }
                    // 测量点的值 10m
                    BigDecimal bPoint = new BigDecimal(pointNumStr);

                    BigDecimal b1 = new BigDecimal("100");//100
                    BigDecimal b2 = new BigDecimal(item.getError());//10
                    BigDecimal b3 = b1.add(b2);//110
                    // 误差
                    BigDecimal bError = b3.divide(b1);//1.1
                    // 波动值 0.01
                    BigDecimal bScope = new BigDecimal(item.getScope());
                    //上限 10*1.1+0.01
                    BigDecimal bUpper = bPoint.multiply(bError).add(bScope);
                    //下限
                    BigDecimal bFloor = bPoint.multiply(bError).subtract(bScope);
                    String section = "[" + bFloor.toString() + ", " + bUpper.toString() + "]";
                    Validity validity = new Validity("直流电阻", item.getRange(), item.getPoint(), section, parameterData.getId());
                    Validity byCondition = validityService.getByCondition(validity.getProject(), validity.getPoint(), validity.getStuId());
                    if (byCondition == null) {
                        validityService.save(validity);
                    } else {
                        byCondition.setSection(validity.getSection());
                        validityService.updateById(byCondition);
                    }
                }
            }
        }
    }

    /**
     * 批量设置参数
     *
     * @param parameterList
     */
    public void setParameterList(List<ParameterData> parameterList) {
        for (ParameterData parameterData : parameterList) {
            setParameter(parameterData);
        }
    }


    /**
     * 根据姓名 项目 parent保存，如果有就更新
     *
     * @param answer
     */
    public void saveAnswer(Answer answer) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", answer.getName()).eq("title", answer.getTitle()).eq("parent", answer.getParent());
        Answer one = answerService.getOne(wrapper);
        if (one == null) {
            answerService.save(answer);
        } else {
            answerService.update(answer, wrapper);
        }

    }

    /**
     * 根据姓名 项目 parent保存，如果有就更新
     *
     * @param answer
     */
    public void saveAnswerIfNull(Answer answer) {
        QueryWrapper<Answer> wrapper = new QueryWrapper<>();
        wrapper.eq("name", answer.getName()).eq("title", answer.getTitle()).eq("parent", answer.getParent());
        Answer one = answerService.getOne(wrapper);
        if (one == null) {
            answerService.save(answer);
        } else {
            //
        }

    }

    /**
     * 查询分数
     *
     * @return
     */
    public List<ScoreDataOne> scoreData() {
        ArrayList<ScoreDataOne> scoreList = new ArrayList<>();
        //获取所有学生
        List<Student> students = list();
        for (Student student : students) {
            //1
            String stuId = String.valueOf(student.getId());
            String name = student.getName();
            //构建每个学生的分数
            ScoreDataOne scoreDataOne = new ScoreDataOne();
            scoreDataOne.setId(student.getId());
            scoreDataOne.setProject(student.getName());
            scoreDataOne.setScore(student.getIdCard());
            scoreDataOne.setTotal(student.getExamEndTime());
            scoreDataOne.setExamState(student.getExamState());
            scoreDataOne.setTotalScore(student.getTotalScore());
            //构建二级项目
            ArrayList<ScoreDataTwo> stuChildren = new ArrayList<>();
            //每一个大项-环境搭建
            List<Answer> list1 = answerService.getByNameAndTitle(name, "环境搭建");
            if (!CollectionUtils.isEmpty(list1)) {
                Answer answer = list1.get(0);
                ScoreDataTwo environment = new ScoreDataTwo();
                //11
                environment.setId(Integer.valueOf(stuId + "1"));
                environment.setProject(answer.getTitle());
                environment.setScore(answer.getScore());
                environment.setTotal(answer.getTotal());
                environment.setParent(answer.getParent());
                environment.setTableId(answer.getId());
                stuChildren.add(environment);
                Answer ans = new Answer();
                try {
                    BeanUtils.copyProperties(ans, answer);
                    ans.setId(null);
                    ans.setParent(-1);
                    ans.setOrderNumber(1);
                    saveAnswer(ans);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            } /*else { //没有环境搭建
                Answer ans = new Answer();
                ans.setScore("0");
                ans.setName(student.getName());
                ans.setTitle("环境搭建");
                ans.setTotal("5");
                ans.setParent(0);
                saveAnswer(ans);
            }*/


            //每一个大项-准备工作-parent=2
            List<Answer> list2 = answerService.getByNameAndParent(name, 2);
            if (!CollectionUtils.isEmpty(list1)) {
                //准备工作菜单
                ScoreDataTwo prepare = new ScoreDataTwo();
                //132
                prepare.setId(Integer.valueOf(stuId + "2"));
                prepare.setProject("准备工作");
                double prepareScore = 0;

                // 准备工作的子项目
                ArrayList<ScoreDataTwo> prepareChildren = new ArrayList<>();
                // 循环准备工作的每一个子项
                for (int i = 0; i < list2.size(); i++) {
                    Answer answer = list2.get(i);
                    ScoreDataTwo s = new ScoreDataTwo();
                    s.setId(Integer.valueOf(stuId + "2" + String.valueOf(i + 1)));
                    s.setProject(answer.getTitle());
                    s.setScore(answer.getScore());
                    s.setTotal(answer.getTotal());
                    s.setParent(answer.getParent());
                    s.setTableId(answer.getId());
                    prepareScore += Double.valueOf(s.getScore());

                    prepareChildren.add(s);
                }
                prepare.setScore(String.valueOf(prepareScore));
                prepare.setTotal("2");
                prepare.setChildren(prepareChildren);
                stuChildren.add(prepare);
                Answer ans = new Answer();
                try {
                    // 添加准备工作大类分数
                    BeanUtils.copyProperties(ans, prepare);
                    ans.setName(name);
                    ans.setTitle(prepare.getProject());
                    ans.setId(null);
                    ans.setParent(-1);
                    ans.setOrderNumber(2);
                    saveAnswer(ans);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            } /*else { //没有准备工作
                Answer ans = new Answer();
                ans.setScore("0");
                ans.setName(student.getName());
                ans.setTitle("准备工作");
                ans.setTotal("2");
                ans.setParent(-1);
                saveAnswer(ans);
            }*/

            // 每个大项-选择检定项目
            List<Answer> list3 = answerService.getByNameAndTitle(name, "检定项目选择");
            if (!CollectionUtils.isEmpty(list3)) {
                Answer answer = list3.get(0);
                ScoreDataTwo s = new ScoreDataTwo();
                //13
                s.setId(Integer.valueOf(stuId + "3"));
                s.setProject(answer.getTitle());
                s.setScore(answer.getScore());
                s.setTotal(answer.getTotal());
                s.setParent(answer.getParent());
                s.setTableId(answer.getId());
                stuChildren.add(s);
                Answer ans = new Answer();
                try {
                    // 选择检定项目大类分数
                    BeanUtils.copyProperties(ans, answer);
                    ans.setId(null);
                    ans.setParent(-1);
                    ans.setOrderNumber(3);
                    saveAnswer(ans);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            } /*else { //没有做检定项目选择
                Answer ans = new Answer();
                ans.setScore("0");
                ans.setName(student.getName());
                ans.setTitle("检定项目选择");
                ans.setTotal("1");
                ans.setParent(0);
                saveAnswer(ans);
            }*/


            // -----------------------------------检定过程----------------------
            //直流电压
            List<Answer> list5 = answerService.getByNameAndParent(name, 5);
            //直流电流
            List<Answer> list6 = answerService.getByNameAndParent(name, 6);
            //交流电压
            List<Answer> list7 = answerService.getByNameAndParent(name, 7);
            //交流电流
            List<Answer> list8 = answerService.getByNameAndParent(name, 8);
            //直流电阻
            List<Answer> list9 = answerService.getByNameAndParent(name, 9);
            // 有一个不为空，创建检定过程二级菜单
            if (!CollectionUtils.isEmpty(list5) ||
                    !CollectionUtils.isEmpty(list6) ||
                    !CollectionUtils.isEmpty(list7) ||
                    !CollectionUtils.isEmpty(list8) ||
                    !CollectionUtils.isEmpty(list9)) {
                ScoreDataTwo process = new ScoreDataTwo();
                //14
                process.setId(Integer.valueOf(stuId + "4"));
                process.setProject("检定过程");
                double processScore = 0;
                //检定过程的子菜单
                ArrayList<ScoreDataTwo> processChildren = new ArrayList<>();

                // 1、直流电压项目
                if (!CollectionUtils.isEmpty(list5)) {
                    ScoreDataTwo dv = new ScoreDataTwo();
                    //141
                    dv.setId(Integer.valueOf(stuId + "41"));
                    dv.setProject("直流电压");
                    double dvScore = 0;
                    int dvTotal = 0;
                    //存放直流电压的子菜单
                    ArrayList<ScoreDataTwo> dvChildren = new ArrayList<>();
                    for (int i = 0; i < list5.size(); i++) {
                        Answer answer = list5.get(i);
                        ScoreDataTwo s = new ScoreDataTwo();
                        //1511
                        s.setId(Integer.valueOf(stuId + "41" + String.valueOf(i + 1)));
                        s.setProject(answer.getTitle());
                        s.setScore(answer.getScore());
                        s.setTotal(answer.getTotal());
                        s.setParent(answer.getParent());
                        s.setTableId(answer.getId());
                        dvScore += Double.valueOf(answer.getScore());
                        dvTotal += Double.valueOf(answer.getTotal());
                        dvChildren.add(s);
                    }
                    dv.setScore(String.valueOf(dvScore));
                    dv.setTotal(String.valueOf(dvTotal));
                    dv.setChildren(dvChildren);
                    processChildren.add(dv);
                    processScore += Double.valueOf(dv.getScore());
                }

                // 2、直流电流
                if (!CollectionUtils.isEmpty(list6)) {
                    ScoreDataTwo av = new ScoreDataTwo();
                    //142
                    av.setId(Integer.valueOf(stuId + "42"));
                    av.setProject("直流电流");
                    double avScore = 0;
                    double avTotal = 0;
                    //存放直流电压的子菜单
                    ArrayList<ScoreDataTwo> avChildren = new ArrayList<>();
                    for (int i = 0; i < list6.size(); i++) {
                        Answer answer = list6.get(i);
                        ScoreDataTwo s = new ScoreDataTwo();
                        //1521
                        s.setId(Integer.valueOf(stuId + "42" + String.valueOf(i + 1)));
                        s.setProject(answer.getTitle());
                        s.setScore(answer.getScore());
                        s.setTotal(answer.getTotal());
                        s.setParent(answer.getParent());
                        s.setTableId(answer.getId());
                        avScore += Double.valueOf(answer.getScore());
                        avTotal += Double.valueOf(answer.getTotal());
                        avChildren.add(s);
                    }
                    av.setScore(String.valueOf(avScore));
                    av.setTotal(String.valueOf(avTotal));
                    av.setChildren(avChildren);
                    processChildren.add(av);
                    processScore += Double.valueOf(av.getScore());
                }

                // 3、交流电压
                if (!CollectionUtils.isEmpty(list7)) {
                    ScoreDataTwo dc = new ScoreDataTwo();
                    //143
                    dc.setId(Integer.valueOf(stuId + "43"));
                    dc.setProject("交流电压");
                    double dcScore = 0;
                    double dcTotal = 0;
                    //存放交流电压的子菜单
                    ArrayList<ScoreDataTwo> dcChildren = new ArrayList<>();
                    for (int i = 0; i < list7.size(); i++) {
                        Answer answer = list7.get(i);
                        ScoreDataTwo s = new ScoreDataTwo();
                        //1431
                        s.setId(Integer.valueOf(stuId + "43" + String.valueOf(i + 1)));
                        s.setProject(answer.getTitle());
                        s.setScore(answer.getScore());
                        s.setTotal(answer.getTotal());
                        s.setParent(answer.getParent());
                        s.setTableId(answer.getId());
                        dcScore += Double.valueOf(answer.getScore());
                        dcTotal += Double.valueOf(answer.getTotal());
                        dcChildren.add(s);
                    }
                    dc.setScore(String.valueOf(dcScore));
                    dc.setTotal(String.valueOf(dcTotal));
                    dc.setChildren(dcChildren);
                    processChildren.add(dc);
                    processScore += Double.valueOf(dc.getScore());
                }

                // 4、交流电流
                if (!CollectionUtils.isEmpty(list8)) {
                    ScoreDataTwo ac = new ScoreDataTwo();
                    //144
                    ac.setId(Integer.valueOf(stuId + "44"));
                    ac.setProject("交流电流");
                    double acScore = 0;
                    double acTotal = 0;
                    //存放直流电压的子菜单
                    ArrayList<ScoreDataTwo> dcChildren = new ArrayList<>();
                    for (int i = 0; i < list8.size(); i++) {
                        Answer answer = list8.get(i);
                        ScoreDataTwo s = new ScoreDataTwo();
                        //1441
                        s.setId(Integer.valueOf(stuId + "44" + String.valueOf(i + 1)));
                        s.setProject(answer.getTitle());
                        s.setScore(answer.getScore());
                        s.setTotal(answer.getTotal());
                        s.setParent(answer.getParent());
                        s.setTableId(answer.getId());
                        acScore += Double.valueOf(answer.getScore());
                        acTotal += Double.valueOf(answer.getTotal());
                        dcChildren.add(s);
                    }
                    ac.setScore(String.valueOf(acScore));
                    ac.setTotal(String.valueOf(acTotal));
                    ac.setChildren(dcChildren);
                    processChildren.add(ac);
                    processScore += Double.valueOf(ac.getScore());
                }

                // 5、直流电阻
                if (!CollectionUtils.isEmpty(list9)) {
                    ScoreDataTwo dr = new ScoreDataTwo();
                    //145
                    dr.setId(Integer.valueOf(stuId + "45"));
                    dr.setProject("直流电阻");
                    double drScore = 0;
                    double drTotal = 0;
                    //存放直流电压的子菜单
                    ArrayList<ScoreDataTwo> dcChildren = new ArrayList<>();
                    for (int i = 0; i < list9.size(); i++) {
                        Answer answer = list9.get(i);
                        ScoreDataTwo s = new ScoreDataTwo();
                        //1451
                        s.setId(Integer.valueOf(stuId + "45" + String.valueOf(i + 1)));
                        s.setProject(answer.getTitle());
                        s.setScore(answer.getScore());
                        s.setTotal(answer.getTotal());
                        s.setParent(answer.getParent());
                        s.setTableId(answer.getId());
                        drScore += Double.valueOf(answer.getScore());
                        drTotal += Double.valueOf(answer.getTotal());
                        dcChildren.add(s);
                    }
                    dr.setScore(String.valueOf(drScore));
                    dr.setTotal(String.valueOf(drTotal));
                    dr.setChildren(dcChildren);
                    processChildren.add(dr);
                    processScore += Double.valueOf(dr.getScore());
                }


                process.setScore(String.valueOf(processScore));
                process.setTotal("40");
                process.setChildren(processChildren);
                stuChildren.add(process);
                Answer ans = new Answer();
                try {
                    BeanUtils.copyProperties(ans, process);
                    ans.setName(name);
                    ans.setTitle(process.getProject());
                    ans.setId(null);
                    ans.setParent(-1);
                    ans.setOrderNumber(4);
                    saveAnswer(ans);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            }

            /*else { //没有检定项目选择
                Answer ans = new Answer();
                ans.setScore("0");
                ans.setName(student.getName());
                ans.setTitle("检定过程");
                ans.setTotal("40");
                ans.setParent(-1);
                saveAnswer(ans);
            }*/
            ArrayList<String> manualScore = new ArrayList<>();
            //查询是否有手动评分的成绩
            Answer ans1 = answerService.getAnswerByNameTitle(student.getName(), "熟练程度");
            if (ans1 == null) { //还没有评分
                manualScore.add("暂未评分");
                manualScore.add("暂未评分");
                manualScore.add("暂未评分");
                manualScore.add("暂未评分");
            } else {// 已经评分了
                manualScore.add(ans1.getScore());
                Answer ans2 = answerService.getAnswerByNameTitle(student.getName(), "原始记录");
                manualScore.add(ans2.getScore());

                Answer ans3 = answerService.getAnswerByNameTitle(student.getName(), "报告正确性");
                manualScore.add(ans3.getScore());

                Answer ans4 = answerService.getAnswerByNameTitle(student.getName(), "实验后仪器整理");
                manualScore.add(ans4.getScore());
            }
            scoreDataOne.setChildren(stuChildren);
            scoreDataOne.setManualScore(manualScore);
            scoreList.add(scoreDataOne);
        }
        return scoreList;
    }

    /**
     * 更新考试时间
     *
     * @param date
     */
    public void updateExamStartTime(Date date) {
        List<Student> students = list();
        for (Student student : students) {
            Student stu = new Student();
            stu.setId(student.getId());
            stu.setExamStartTime(date);
            updateById(stu);
        }
    }

    public Student getByIdCard(String idCard) {
        QueryWrapper<Student> wrapper = new QueryWrapper<>();
        wrapper.eq("id_card", idCard);
        return getOne(wrapper);
    }


    public boolean isSetParameter(int[] stuIds) {
        boolean flag = true;
        //有一个是false，就是false
        for (int stuId : stuIds) {
            Student student = getById(stuId);
            flag = flag && student.getParameterState();
        }
        return flag;
    }
}
