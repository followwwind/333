package com.liaoxiang.multimeter.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.liaoxiang.multimeter.mapper.ValidityMapper;
import com.liaoxiang.multimeter.pojo.Answer;
import com.liaoxiang.multimeter.pojo.validity.Item;
import com.liaoxiang.multimeter.pojo.validity.Validity;
import com.liaoxiang.multimeter.pojo.validity.ValidityData;
import com.liaoxiang.multimeter.service.IValidityService;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/6/16 0:36
 */
@Service
public class ValidityServiceImpl extends ServiceImpl<ValidityMapper, Validity> implements IValidityService {

    public Validity getByCondition(String project, String point, Integer stuId) {
        QueryWrapper<Validity> wrapper = new QueryWrapper<>();
        wrapper.eq("project", project).eq("point",point).eq("stu_id", stuId);
        return getOne(wrapper);
    }


    public List<ValidityData> getValidity(Integer stuId) {
        ArrayList<ValidityData> list = new ArrayList<>();
        QueryWrapper<Validity> wrapper = new QueryWrapper<>();
        wrapper.eq("stu_id", stuId);
        List<Validity> validityList = list(wrapper);
        //直流电压
        ArrayList<Item> list0 = new ArrayList<>();
        //直流电流
        ArrayList<Item> list1 = new ArrayList<>();
        //交流电压
        ArrayList<Item> list2 = new ArrayList<>();
        //交流电流
        ArrayList<Item> list3 = new ArrayList<>();
        //直流电阻
        ArrayList<Item> list4 = new ArrayList<>();
        for (Validity validity : validityList) {
            if (validity.getProject().equals("直流电压")) {
                list0.add(new Item(validity.getVRange(),validity.getPoint(),validity.getSection()));
            }
            if (validity.getProject().equals("直流电流")) {
                list1.add(new Item(validity.getVRange(),validity.getPoint(),validity.getSection()));
            }
            if (validity.getProject().equals("交流电压")) {
                list2.add(new Item(validity.getVRange(),validity.getPoint(),validity.getSection()));
            }
            if (validity.getProject().equals("交流电流")) {
                list3.add(new Item(validity.getVRange(),validity.getPoint(),validity.getSection()));
            }
            if (validity.getProject().equals("直流电阻")) {
                list4.add(new Item(validity.getVRange(),validity.getPoint(),validity.getSection()));
            }
        }
        if (!CollectionUtils.isEmpty(list0)) {
            list.add(new ValidityData("直流电压", list0));
        }
        if (!CollectionUtils.isEmpty(list1)) {
            list.add(new ValidityData("直流电流", list1));
        }
        if (!CollectionUtils.isEmpty(list2)) {
            list.add(new ValidityData("交流电压", list2));
        }
        if (!CollectionUtils.isEmpty(list3)) {
            list.add(new ValidityData("交流电流", list3));
        }
        if (!CollectionUtils.isEmpty(list4)) {
            list.add(new ValidityData("直流电阻", list4));
        }
        return list;
    }

    public void deleteOldData(Integer  stuId) {
        QueryWrapper<Validity> wrapper = new QueryWrapper<>();
        wrapper.eq("stu_id", stuId);
        remove(wrapper);
    }
}
