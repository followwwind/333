package com.liaoxiang.multimeter.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.liaoxiang.multimeter.mapper.LogDataMapper;
import com.liaoxiang.multimeter.pojo.LogData;
import com.liaoxiang.multimeter.service.ILogDataService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @auther Mr.Liao
 * @date 2021/6/1 23:02
 */
@Service
public class LogDataServiceImpl extends ServiceImpl<LogDataMapper, LogData> implements ILogDataService {

    public List<LogData> getLogDataByName(String name) {
        QueryWrapper<LogData> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name);
        return list(wrapper);
    }


    public void deleteOldData(String name) {
        QueryWrapper<LogData> wrapper = new QueryWrapper<>();
        wrapper.eq("name", name);
        remove(wrapper);
    }
}
