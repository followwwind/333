package com.liaoxiang.multimeter.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.liaoxiang.multimeter.pojo.LogData;

/**
 * @auther Mr.Liao
 * @date 2021/6/1 23:01
 */
public interface ILogDataService extends IService<LogData> {
}
