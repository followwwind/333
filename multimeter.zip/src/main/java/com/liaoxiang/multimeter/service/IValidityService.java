package com.liaoxiang.multimeter.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.liaoxiang.multimeter.pojo.validity.Validity;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:35
 */
public interface IValidityService extends IService<Validity> {
}
