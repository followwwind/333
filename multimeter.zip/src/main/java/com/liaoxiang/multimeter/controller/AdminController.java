package com.liaoxiang.multimeter.controller;

import com.liaoxiang.multimeter.pojo.Parameter;
import com.liaoxiang.multimeter.pojo.Response;
import com.liaoxiang.multimeter.pojo.Student;
import com.liaoxiang.multimeter.pojo.UpdateScoreData;
import com.liaoxiang.multimeter.pojo.parameter.ParameterData;
import com.liaoxiang.multimeter.pojo.score_data.OtherScoreData;
import com.liaoxiang.multimeter.service.impl.AnswerServiceImpl;
import com.liaoxiang.multimeter.service.impl.StudentServiceImpl;
import com.liaoxiang.multimeter.service.impl.ValidityServiceImpl;
import com.liaoxiang.multimeter.utils.LocalCatch;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @auther Mr.Liao
 * @date 2021/5/28 9:23
 */
@Slf4j
@RestController
@RequestMapping("admin")
public class AdminController {

    @Autowired
    StudentServiceImpl studentService;

    @Autowired
    AnswerServiceImpl answerService;

    @Autowired
    ValidityServiceImpl validityService;

    @Autowired
    SimpMessagingTemplate messagingTemplate;

    /**
     * 管理员登录
     *
     * @param name
     * @param password
     * @return
     */
    @ApiOperation("管理员登录")
    @GetMapping("login")
    public Response login(@RequestParam String name, @RequestParam String password) {
        Map<String, String> adminMap = LocalCatch.adminMap;
        if (adminMap.containsKey(name)) {
            String pwd = adminMap.get(name);
            if (password.equals(pwd)) {
                return new Response(true, "登录成功", null);
            } else return new Response(false, "密码错误", null);
        } else return new Response(false, "用户名错误", null);
    }

    /**
     * 开始考试
     *
     * @param stuIds
     * @return
     */
    @ApiOperation("批量设置开始考试")
    @PostMapping("exam_start")
    public Response updateStart(@RequestBody int[] stuIds) {
        //更新每一个考生开始考试的标识
        for (int i = 0; i < stuIds.length; i++) {
            studentService.updateStarted(stuIds[i], true);
        }
        //设置默认分数
//        answerService.setDefaultScore();
        return new Response(true, "设置成功", null);
    }

    /**
     * 单个考生设置开始考试
     *
     * @param stuId
     * @return
     */
    @ApiOperation("设置单个考生开始考试")
    @GetMapping("exam_start/{stuId}")
    public Response startExam(@PathVariable Integer stuId) {
        studentService.updateStarted(stuId, true);
        //设置默认分数
//        answerService.setDefaultScore();
        return new Response(true, "设置成功", null);
    }




    /**
     * 单个参数设置
     *
     * @param parameterData
     * @return
     */
    @ApiOperation("单个参数设置")
    @PostMapping("parameter")
    public Response setParameter(@RequestBody ParameterData parameterData) {
        studentService.setParameter(parameterData);
//        messagingTemplate.convertAndSend("/all", studentService.list());
        return new Response(true, "设置成功", null);
    }

    /**
     * 批量设置参数
     *
     * @param parameterList
     * @return
     */
    @ApiOperation("批量设置参数")
    @PostMapping("parameterAll")
    public Response setParameterAll(@RequestBody List<ParameterData> parameterList) {
        studentService.setParameterList(parameterList);
//        messagingTemplate.convertAndSend("/all", studentService.list());
        return new Response(true, "设置成功", null);
    }


    /**
     * 修改分数
     *
     * @param tableId   public 返回值  方法名(){}
     * @param score admin/updateScore?score=0&tableId=9355
     * @return
     */
    @ApiOperation("修改分数")
    @PostMapping("updateScore")
    public Response updateScore(@RequestParam Integer tableId, @RequestParam String score) {
        log.info("修改分数：" + tableId + "，" + score);
        // 9355，0
        answerService.updateScore(tableId, score);
        studentService.scoreData();
        return new Response(true, "修改成功", null);
    }


    /**
     * 修改自动评分之后更新成绩单
     * @param idCard
     * @return
     */
    @ApiOperation("修改自动评分之后更新成绩单")
    @PostMapping("updateScore/{idCard}")
    public Response updateTranscript(@PathVariable String idCard) {
        // 9355，0
        Student stu = studentService.getByIdCard(idCard);
        if (stu.getScored()) {
            log.info("更新总成绩和成绩单");
            answerService.updateTranscript(stu.getName());
        }
        return new Response(true, "更新成功", null);
    }





    /**
     * 提交分数-手动评分
     * @param scoreData
     * @return
     */
    @ApiOperation("手动评分提交分数")
    @PostMapping("saveScore")
    public Response saveScore(@RequestBody OtherScoreData scoreData) {
        answerService.saveScore(scoreData);
        return new Response(true, "提交成功", null);
    }


    @ApiOperation("获取雷达图数据")
    @GetMapping("radarMap")
    public Response getRadarMap(@RequestParam String name) {
        return new Response(true, "查询成功", answerService.getRadarMap(name));
    }


    @ApiOperation("正确性数据")
    @GetMapping("validity")
    public Response getValidity(@RequestParam Integer stuId) {
        return new Response(true, "查询成功", validityService.getValidity(stuId));
    }


    /**
     * 是否已经设置参数
     *
     * @param stuIds
     * @return
     */
    @ApiOperation("是否已经设置参数")
    @PostMapping("isSetParameter")
    public Response isSetParameter(@RequestBody int[] stuIds) {
        return new Response(studentService.isSetParameter(stuIds), "查询成功", null);
    }





}
