package com.liaoxiang.multimeter.controller;

import com.liaoxiang.multimeter.config.MultimeterProperties;
import com.liaoxiang.multimeter.pojo.*;
import com.liaoxiang.multimeter.pojo.parameter.Parameter;
import com.liaoxiang.multimeter.pojo.parameter.ParameterData;
import com.liaoxiang.multimeter.pojo.score_data.ScoreDataOne;
import com.liaoxiang.multimeter.service.impl.AnswerServiceImpl;
import com.liaoxiang.multimeter.service.impl.LogDataServiceImpl;
import com.liaoxiang.multimeter.service.impl.StudentServiceImpl;
import com.liaoxiang.multimeter.service.impl.ValidityServiceImpl;
import com.liaoxiang.multimeter.utils.IpUtils;
import com.liaoxiang.multimeter.utils.LocalCatch;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 14:19
 */
@RestController
@RequestMapping("stu")
@CrossOrigin
@Slf4j
public class StudentController {

    @Autowired
    StudentServiceImpl studentService;

    @Autowired
    AnswerServiceImpl answerService;

    @Autowired
    LogDataServiceImpl logDataService;

    @Autowired
    ValidityServiceImpl validityService;

    @Autowired
    MultimeterProperties multimeterProperties;

    @Autowired
    SimpMessagingTemplate messagingTemplate;

    @ApiOperation("查询所有考生信息")
    @GetMapping("all")
    public Response findAllStu() {
        return new Response(true, "", studentService.list());
    }

    @ApiOperation("考生登录")
    @GetMapping("login")
    public Response login(@RequestParam String name,
                          @RequestParam String password,
                          HttpServletRequest request) {
        log.info("考生登录：" + name + "-" + password);
        Student student = studentService.login(name, password);
        if (student == null) {
            return new Response(1, false, "用户名或密码错误", null);
        } else {
            //查询是否在线，如果在线提示无法登录
            if (student.getState()) {
                return new Response(1, false, "无法同时在线", null);
            }
            //查询考试项目
            //更新IP地址和在线状态
            String ipAddr = IpUtils.getIpAddr(request);
            student.setIp(ipAddr);
            student.setState(true);//在线状态
            studentService.updateById(student);
            messagingTemplate.convertAndSend("/all", studentService.list());
            return new Response(1, true, "登录成功", student);
        }
    }

    /**
     * 查询参数
     *
     * @param id
     * @return
     */
    @ApiOperation("查询考试参数和项目")
    @GetMapping("parameter")
    public Response getParameter(@RequestParam Integer id) {
        ParameterData parameter = LocalCatch.parameterMap.get(id);
        log.info(id+ "查询参数" + parameter);
//        LocalCatch.parameterMap.remove(id);
        return new Response(2, true, "查询成功", parameter);
    }


    /**
     * 查询考试开始标识
     *
     * @return
     */
    @ApiOperation("查询考试开始标识")
    @GetMapping("exam_start/{stuId}")
    public Response getStart(@PathVariable Integer stuId) {
        Student student = studentService.getById(stuId);
        return new Response(3, student.getStarted(), "查询成功", null);
    }


    /**
     * 提交答案
     *
     * @param answer
     * @return
     */
    @ApiOperation("提交答案")
    @PostMapping("answer")
    public Response saveAnswer(@RequestBody Answer answer) {
//        log.info(answer.getName()+"，提交的答案：" + answer);
        studentService.saveAnswer(answer);//有就更新
        return new Response(4, true, "提交成功", null);
    }


    /**
     * 添加日志
     *
     * @param logData
     * @return
     */
    @ApiOperation("添加日志")
    @PostMapping("log")
    public Response saveLog(@RequestBody LogData logData) {
//        log.info(logData.getName() + "提交操作日志：" + logData);
        logDataService.save(logData);
        return new Response(5, true, "提交成功", null);
    }


    /**
     * 分数查询
     *
     * @return
     */
    @ApiOperation("查询分数")
    @GetMapping("scoreData")
    public Response getScoreData() {
//        log.info("查询成绩");
        List<ScoreDataOne> scoreDataOnes = studentService.scoreData();
        return new Response(true, "查询成功", scoreDataOnes);
    }

    /**
     * 查询日志
     *
     * @param name
     * @return
     */
    @ApiOperation("查询日志")
    @GetMapping("log")
    public Response getLogData(@RequestParam String name) {
            return new Response(true, "查询成功", logDataService.getLogDataByName(name));
    }


    /**
     * 查询PDF
     *
     * @param idCard
     */
    @ApiOperation("查看原始记录获取PDF")
    @GetMapping("pdf/{idCard}")
    public void getPDF(@PathVariable String idCard, HttpServletResponse response) {
        log.info("下载原始记录，idCard：" + idCard);
        Student stu = studentService.getByIdCard(idCard);
        if (stu != null) {
            String pdfPath = multimeterProperties.getPdfPath();
            pdfPath = pdfPath + idCard + ".pdf";
            File file = new File(pdfPath);
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                byte[] bytes = new byte[fileInputStream.available()];
                fileInputStream.read(bytes);
                response.getOutputStream().write(bytes);
            } catch (Exception e) {
                log.info("原始记录文件不存在：" + idCard);
            }
        }
    }


    /**
     * 查询PDF
     *
     * @param idCard
     */
    @ApiOperation("下载成绩单")
    @GetMapping("transcript/{idCard}")
    public void getTranscript(@PathVariable String idCard, HttpServletResponse response) {
        log.info("下载PDF，idCard：" + idCard);
        String scorePath = multimeterProperties.getScorePath();
        scorePath = scorePath + idCard + "transcript.pdf";
        File file = new File(scorePath);
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bytes = new byte[fileInputStream.available()];
            fileInputStream.read(bytes);
            response.getOutputStream().write(bytes);
        } catch (Exception e) {
            log.info("成绩单文件不存在");
        }
    }

    @ApiOperation("查询是否已经完成评分")
    @GetMapping("isScored/{idCard}")
    public Response isScored(@PathVariable String idCard) {
        Student stu = studentService.getByIdCard(idCard);
        if (stu.getScored()) {
            return new Response(true, "完成评分", null);
        } else {
            return new Response(false, "未完成评分", null);
        }
    }

    /**
     * 考试结束，修改状态
     * @param id
     * @return
     */
    @ApiOperation("考试结束，修改状态")
    @GetMapping("examEnd/{id}")
    public Response examEnd(@PathVariable Integer id) {
        log.info("已结束考试：" + id);
        // 考试结束更新状态
        Student stu = studentService.getById(id);
        stu.setExamState("已完成考试");
        stu.setState(false);//不在线
        stu.setIp(" ");//清空ip
        stu.setStarted(false);//开始考试 false
        stu.setParameterState(false);//未设置参数
        stu.setExamEndTime(new Date());//结束时间
        studentService.updateById(stu);
        //其他操作
        ParameterData parameterData = LocalCatch.parameterMap.get(id);
        if (parameterData != null) {
            //填充未考试项目的分数
            ArrayList<Parameter> parameters = parameterData.getParameters();
            // 已选择有哪些type
            HashSet<Integer> typeSet = new HashSet<>();
            for (Parameter parameter : parameters) {
                typeSet.add(parameter.getType());
            }
            // 0-直流电压-5 1-直流电流-6 2-交流电压-7 3-交流电流-8 4-直流电阻-9
            log.info(stu.getName() +" 已做项目：" + typeSet.toString());
            for (int i = 0; i < 5; i++) {
                // 已做项目
                if (typeSet.contains(i)) {
                    continue;
                } else {// 未作项目
                    log.info(stu.getName() +" 未做项目：" + i);
                    String name = stu.getName();
                    if (i == 0) {
                        createAns(name, 5);
                    }
                    if (i == 1) {
                        createAns(name, 6);
                    }
                    if (i == 2) {
                        createAns(name, 7);
                    }
                    if (i == 3) {
                        createAns(name, 8);
                    }
                    if (i == 4) {
                        createAns(name, 9);
                    }

                }
            }
            //计算正确性数据
            studentService.setValidity(parameterData);
            LocalCatch.parameterMap.remove(id);//清除参数
        }
        //实时更新页面数据
        messagingTemplate.convertAndSend("/all", studentService.list());
        messagingTemplate.convertAndSend("/scoreData", studentService.scoreData());
        return new Response(5,true, "提交成功", null);
    }

    public void createAns(String name, int parent) {
        answerService.save(new Answer(name, parent, "连线", "1", "1"));
        answerService.save(new Answer(name, parent, "选点", "1", "1"));
        answerService.save(new Answer(name, parent, "操作", "6", "6"));
    }

    /**
     * 异常结束，修改状态
     * @param id
     * @return
     */
    @ApiOperation("异常结束")
    @GetMapping("quit/{id}")
    public Response quit(@PathVariable Integer id) {
        log.info("异常结束：" + id);
        Student stu = studentService.getById(id);
        stu.setExamState("异常结束");
        stu.setState(false); //不在线
        stu.setStarted(false); //开始考试设置false
        stu.setIp(" ");
        stu.setExamEndTime(new Date());
        studentService.updateById(stu);
        messagingTemplate.convertAndSend("/scoreData", studentService.scoreData());
        return new Response(true, "提交成功", null);
    }

}
