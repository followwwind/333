package com.liaoxiang.multimeter.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.liaoxiang.multimeter.config.MultimeterProperties;
import com.liaoxiang.multimeter.listener.StudentListener;
import com.liaoxiang.multimeter.pojo.Student;
import com.liaoxiang.multimeter.service.impl.StudentServiceImpl;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import sun.rmi.runtime.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 14:19
 */
@Slf4j
@RestController
@RequestMapping("file")
public class FileController {

    @Autowired
    StudentListener studentListener;

    @Autowired
    MultimeterProperties multimeterProperties;

    @Autowired
    StudentServiceImpl studentService;

    /**
     *
     *
     * 导入考生信息的excel表格
     * @param file
     */
    @ApiOperation("上传考生信息Excel")
    @PostMapping("student_excel")
    public void parseExcel(MultipartFile file) {
        try {
            ExcelReaderBuilder builder = EasyExcel.read(file.getInputStream(),
                    Student.class, studentListener);
            builder.sheet(0).doRead();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 上传PDF
     *
     * @param file
     */
    @ApiOperation("上传PDF")
    @PostMapping("pdf")
    public void uploadPDF(@RequestParam("file") MultipartFile[] file) {
        for (MultipartFile multipartFile : file) {
            String originalFilename = multipartFile.getOriginalFilename();
            log.info("文件名称：" + originalFilename);
            try {
                String imagePath = multimeterProperties.getPdfPath();
                File filePath = new File(imagePath + originalFilename);
                multipartFile.transferTo(filePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String filename = multipartFile.getOriginalFilename();
            String idCard = filename.substring(0, filename.indexOf("."));
            Student stu = studentService.getStuByIdCard(idCard);
            if (stu == null) {
                log.info("原始记录名称错误，没有对应考生");
                return;
            }
            log.info(stu.getName() + "上传的原始记录：" + filename);
        }
    }


}
