package com.liaoxiang.multimeter.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liaoxiang.multimeter.pojo.LogData;
import org.apache.ibatis.annotations.Mapper;


/**
 * @auther Mr.Liao
 * @date 2021/6/1 23:02
 */
@Mapper
public interface LogDataMapper extends BaseMapper<LogData> {
}
