package com.liaoxiang.multimeter.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liaoxiang.multimeter.pojo.validity.Validity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:35
 */
@Mapper
public interface ValidityMapper extends BaseMapper<Validity> {

}
