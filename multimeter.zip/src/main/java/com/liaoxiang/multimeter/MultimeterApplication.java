package com.liaoxiang.multimeter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class MultimeterApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultimeterApplication.class, args);
    }

}
