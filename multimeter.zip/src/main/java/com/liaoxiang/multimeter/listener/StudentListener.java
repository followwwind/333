package com.liaoxiang.multimeter.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.liaoxiang.multimeter.pojo.Student;
import com.liaoxiang.multimeter.service.impl.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @auther Mr.Liao
 * @date 2021/5/27 15:33
 */
@Component
@Scope("prototype")
public class StudentListener extends AnalysisEventListener<Student> {
    @Autowired
    private StudentServiceImpl studentService;

    @Override
    public void invoke(Student student, AnalysisContext analysisContext) {
        Student stu = studentService.getByIdCard(student.getIdCard());
        if (stu == null) {
            student.setPassword(getPassword(student.getIdCard()));
            System.out.println(student);
            studentService.save(student);
        } else {
            student.setId(stu.getId());
            studentService.updateById(student);
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }

    private  String getPassword(String str) {
        return str.substring(str.length() -6);
    }

}
