package com.liaoxiang.multimeter;

import com.liaoxiang.multimeter.pojo.Student;
import com.liaoxiang.multimeter.pojo.validity.Validity;
import com.liaoxiang.multimeter.service.impl.StudentServiceImpl;
import com.liaoxiang.multimeter.service.impl.ValidityServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class MultimeterApplicationTests {



}
