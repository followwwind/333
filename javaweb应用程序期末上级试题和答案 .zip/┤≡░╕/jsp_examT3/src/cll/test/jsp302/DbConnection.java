package cll.test.jsp302;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	static Connection conn;
	public static Connection getConnection()  {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn= DriverManager.getConnection("jdbc:mysql://www.malikcheng.xin/jsptest","test","123");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("connection success");
		return conn;
	}
public static void main(String[] args) throws Exception {
	DbConnection.getConnection();
}
}
