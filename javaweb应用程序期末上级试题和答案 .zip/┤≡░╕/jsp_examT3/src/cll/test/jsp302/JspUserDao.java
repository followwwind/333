package cll.test.jsp302;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JspUserDao {
	Connection conn =DbConnection.getConnection();
	
	Statement sta;
	ResultSet rst;
	public ArrayList<JspUser> getAll() {
		ArrayList<JspUser> users = new ArrayList<JspUser>();
		
		String sql ="select * from jspuser";
		try {
			sta = conn.createStatement();
			rst = sta.executeQuery(sql);
			while(rst.next()){
				JspUser user = new JspUser();
				user.setEmail(rst.getString("Email"));
				user.setId(rst.getShort("id"));
				user.setPassword(rst.getString("password"));
				user.setUsername(rst.getString("username"));
				users.add(user);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return users;
		
	}
	public JspUser getUserById(int id){
		JspUser user = new JspUser();
		String sql = "select * from jspuser where id="+id;		try {
			sta = conn.createStatement();
			rst = sta.executeQuery(sql);
			if(rst.next()){
				user.setEmail(rst.getString("Email"));
				user.setId(rst.getShort("id"));
				user.setPassword(rst.getString("password"));
				user.setUsername(rst.getString("username"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return user;
	}
	public ArrayList<JspUser> getByLikeName(String name){
		ArrayList<JspUser>  users = new ArrayList<JspUser>();
		try {
			sta = conn.createStatement();
			rst = sta.executeQuery("select * from jspuser where username like "
					+ "'%"+name+"%'");
			while(rst.next()){
				JspUser user = new JspUser();
				user.setEmail(rst.getString("Email"));
				user.setId(rst.getShort("id"));
				user.setPassword(rst.getString("password"));
				user.setUsername(rst.getString("username"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}
	public static void main(String[] args) {
		JspUserDao d = new JspUserDao();
		JspUser user = new JspUser();
		user.setUsername("test1");
		user.setPassword("test123");
		/*ArrayList<JspUser> users =  d.getByLikeName("test1");
		for (JspUser jspUser : users) {
			System.out.println(jspUser.getEmail());
			System.out.println(jspUser.getId());
			System.out.println(jspUser.getPassword());
			System.out.println(jspUser.getUsername());
			System.out.println("-------------");
		}*/
		JspUser jspUser = d.getUserById(5);
		
		System.out.println(jspUser.getEmail());
		System.out.println(jspUser.getId());
		System.out.println(jspUser.getPassword());
		System.out.println(jspUser.getUsername());
		System.out.println("-------------");
	}
}
