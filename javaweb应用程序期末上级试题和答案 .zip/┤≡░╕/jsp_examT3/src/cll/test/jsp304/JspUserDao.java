package cll.test.jsp304;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JspUserDao {
	Connection conn;	
	public JspUserDao(){
			conn = DbConnection.getConnection();
		}
	public ArrayList<JspUser> getAll() {
		 ArrayList<JspUser> users = new ArrayList<JspUser>();
		Statement sta;
		ResultSet rst;
		String sql ="select * from jspuser ";
		
		try {	sta = conn.createStatement();
				rst = sta.executeQuery(sql);
				while(rst.next())
				{	JspUser user = new JspUser();
					user.setEmail(rst.getString("email"));
					user.setId(rst.getInt("id"));
					user.setUsername(rst.getString("username"));
					user.setPassword(rst.getString("password"));
					users.add(user);
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return users;
	}	
	public JspUser getUserbyId(int id) throws SQLException {
		JspUser user  = new JspUser();
		Statement sta = conn.createStatement();
		ResultSet rst = sta.executeQuery("select * from jspuser where id="+id);
		if(rst.next()){
			
			user.setEmail(rst.getString("email"));
			user.setPassword(rst.getString("password"));
			user.setUsername(rst.getString("username"));
		}
		return user;
	}
	public int  updateUser(JspUser user) throws SQLException {
		PreparedStatement pres = conn.prepareStatement(
				"update jspuser set username =?,password = ?,email = ? where id =?");
		pres.setString(1, user.getUsername());
		pres.setString(2, user.getPassword());
		pres.setString(3, user.getEmail());
		pres.setInt(4, user.getId());
		return pres.executeUpdate();
	}
	public static void main(String[] args) throws SQLException {
		JspUserDao d = new JspUserDao();
		JspUser u = new JspUser();
		u.setUsername("test4");
		u.setEmail("4");
		u.setPassword("test4");
		u.setId(2);
		System.out.println(d.updateUser(u));
		
		
	}
}
