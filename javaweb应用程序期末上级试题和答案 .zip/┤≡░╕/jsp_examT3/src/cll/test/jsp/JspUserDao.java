package cll.test.jsp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JspUserDao {
	Connection conn = DbConnection.getConnection();
	
	Statement sta;
	ResultSet rst;
	public boolean login(JspUser user){
		String name = user.getUsername();
		String pwd = user.getPassword();
		String sql = "select * from jspuser where username='"
				+name+"'and Password = '"+pwd+"'";
		try {
			sta= conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("sta is not correct ");
		}
		try {
			rst = sta.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("rst is not correct ");
		}
		try {
			if(rst.next()){
				System.out.println("-------login is success ! ");
				sta.close();
				rst.close();
				conn.close();
				return true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			return false;
	}
	/*public static void main(String[] args) {
		JspUserDao d = new JspUserDao();
		JspUser user = new JspUser();
		user.setUsername("test1");
		user.setPassword("test123");
		d.login(user);
	}*/
}
