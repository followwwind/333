package cll.test.jsp303;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JspUserDao {
	Connection conn;	
	public JspUserDao(){
			conn = DbConnection.getConnection();
		}
	public boolean isHaveUserOrEamil( JspUser user) {
		Statement sta;
		ResultSet rst;
		String sql ="select * from jspuser  where username ='"+user.getUsername()+
				"'or Email ='"+user.getEmail()+"'";
		
		try {	sta = conn.createStatement();
				rst = sta.executeQuery(sql);
				if(rst.next())
					return false;
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return true;
	}	
	public int  insertUser(JspUser user) throws SQLException {
//		PreparedStatement prs = (PreparedStatement) conn.prepareStatement("insert into jspuser values(?,?,?,?)");
		java.sql.PreparedStatement pres = conn.prepareStatement("insert into jspuser(username,email,password) values(?,?,?)");
		pres.setString(1, user.getUsername());
		pres.setString(2, user.getEmail());
		pres.setString(3, user.getPassword());
		int result = pres.executeUpdate();
		return result;
		
	}
	public static void main(String[] args) throws SQLException {
		JspUserDao d = new JspUserDao();
		JspUser u = new JspUser();
		u.setUsername("test4");
		u.setEmail("4");
		u.setPassword("test4");
		System.out.println(d.isHaveUserOrEamil(u));
		System.out.println(d.insertUser(u));
		
	}
}
