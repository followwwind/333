package cll.test.jsp303;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	static Connection conn;
	public static Connection getConnection (){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {	
			conn = DriverManager.getConnection(
					"jdbc:mysql://www.malikcheng.xin:3306/jsptest"
					,"test","123");
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		System.out.println("success ！");
		return conn;
	}
//	public static void main(String[] args) {
//		DbConnection.getConnection();
//	}
}
