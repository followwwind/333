package cll.test.jsp305;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JspUserDao {
	Connection conn;	
	public JspUserDao(){
			conn = DbConnection.getConnection();
		}
	public ArrayList<JspUser> getAll() {
		 ArrayList<JspUser> users = new ArrayList<JspUser>();
		Statement sta;
		ResultSet rst;
		String sql ="select * from jspuser ";
		
		try {	sta = conn.createStatement();
				rst = sta.executeQuery(sql);
				while(rst.next())
				{	JspUser user = new JspUser();
					user.setEmail(rst.getString("email"));
					user.setId(rst.getInt("id"));
					user.setUsername(rst.getString("username"));
					user.setPassword(rst.getString("password"));
					users.add(user);
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}	
	public int  delUserById(int id) throws SQLException {
			String sql ="delete  from jspuser where id="+id;
			Statement sta = conn.createStatement();
			
		return sta.executeUpdate(sql);
	}
	/*public static void main(String[] args) throws SQLException {
		JspUserDao d = new JspUserDao();
		JspUser u = new JspUser();
		u.setUsername("test4");
		u.setEmail("4");
		u.setPassword("test4");
		u.setId(2);
		System.out.println(d.updateUser(u));
	}*/
}
