INFO 5100 Assignment 3
=======================
Northeastern University 2021 summer

Team Member
-----------------------
Jialai Wu (wu.jial@northeastern.edu)<br>
Minghui Qiu (qiu.min@northeastern.edu)<br>
Qian Yu (yu.qian1@northeastern.edu)

Dependency
-----------------------
javafaker-1.0.2<br>
jdatepicker-1.3.4<br>
json-20210307<br>
<br>
all dependencies are located in `lib/ `, please include them in your project

Task Assignment
-----------------------
under construction...

Final Report
-----------------------
under construction...
